package soen343.lab1.exceptions;

public class XHtmlBadFormatException extends Exception {

	public XHtmlBadFormatException(String message) {
		super(message);
	}
	
}
