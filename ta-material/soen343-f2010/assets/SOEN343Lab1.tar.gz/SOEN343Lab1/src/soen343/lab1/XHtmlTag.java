package soen343.lab1;

public class XHtmlTag {

	private String tagName;
	
	public XHtmlTag(String tagName) {
		this.tagName = tagName;
	}
	
	public boolean equals(Object o) {
		if(o instanceof XHtmlTag) {
			XHtmlTag otherTagName = (XHtmlTag)o;
			return otherTagName.tagName.equals(this.tagName);
		}
		return false;
	}
	
	public int hashCode() {
		return 643*tagName.hashCode();
	}
	
	public String getTagName() {
		return tagName;
	}
	
}
