package soen343.lab1.test.elements;

import junit.framework.TestCase;
import soen343.lab1.XHtmlSanitizer;
import soen343.lab1.exceptions.XHtmlBadFormatException;

public class TestTdElement extends TestCase {

	public void testElementNoAttributes() throws XHtmlBadFormatException {
		String input = " <td>innerHTML - this is a test</td> ";
		String expected = " <td>innerHTML - this is a test</td> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementHeadersAttribute() throws XHtmlBadFormatException {
		String input = " <td headers=\"value\">innerHTML - this is a test</td> ";
		String expected = " <td headers=\"value\">innerHTML - this is a test</td> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementColspanAttribute() throws XHtmlBadFormatException {
		String input = " <td headers=\"value\" colspan=\"value\">innerHTML - this is a test</td> ";
		String expected = " <td headers=\"value\" colspan=\"value\">innerHTML - this is a test</td> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementRowspanAttribute() throws XHtmlBadFormatException {
		String input = " <td headers=\"value\" colspan=\"value\" rowspan=\"value\">innerHTML - this is a test</td> ";
		String expected = " <td headers=\"value\" colspan=\"value\" rowspan=\"value\">innerHTML - this is a test</td> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementAxisAttribute() throws XHtmlBadFormatException {
		String input = " <td headers=\"value\" colspan=\"value\" rowspan=\"value\" axis=\"value\">innerHTML - this is a test</td> ";
		String expected = " <td headers=\"value\" colspan=\"value\" rowspan=\"value\" axis=\"value\">innerHTML - this is a test</td> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementBadAttribute() throws XHtmlBadFormatException {
		String input = " <td headers=\"value\" colspan=\"value\" rowspan=\"value\" axis=\"value\" OnClick=\"alert('bad!');\">innerHTML - this is a test</td> ";
		String expected = " <td headers=\"value\" colspan=\"value\" rowspan=\"value\" axis=\"value\">innerHTML - this is a test</td> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

}
