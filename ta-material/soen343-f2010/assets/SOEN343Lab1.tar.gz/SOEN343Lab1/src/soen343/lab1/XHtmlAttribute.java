package soen343.lab1;

public class XHtmlAttribute {

	private String attributeName;
	
	public XHtmlAttribute(String attributeName) {
		this.attributeName = attributeName;
	}
	
	public boolean equals(Object o) {
		if(o instanceof XHtmlAttribute) {
			XHtmlAttribute otherAttributeName = (XHtmlAttribute)o;
			return otherAttributeName.attributeName.equals(this.attributeName);
		}
		return false;
	}
	
	public int hashCode() {
		return 641*attributeName.hashCode();
	}
	
	public String getAttributeName() {
		return attributeName;
	}
}
