package soen343.lab1.test.elements;

import junit.framework.TestCase;
import soen343.lab1.XHtmlSanitizer;
import soen343.lab1.exceptions.XHtmlBadFormatException;

public class TestTableElement extends TestCase {

	public void testElementNoAttributes() throws XHtmlBadFormatException {
		String input = " <table>innerHTML - this is a test</table> ";
		String expected = " <table>innerHTML - this is a test</table> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementCellpaddingAttribute()
			throws XHtmlBadFormatException {
		String input = " <table cellpadding=\"value\">innerHTML - this is a test</table> ";
		String expected = " <table cellpadding=\"value\">innerHTML - this is a test</table> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementCellspacingAttribute()
			throws XHtmlBadFormatException {
		String input = " <table cellpadding=\"value\" cellspacing=\"value\">innerHTML - this is a test</table> ";
		String expected = " <table cellpadding=\"value\" cellspacing=\"value\">innerHTML - this is a test</table> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementSummaryAttribute() throws XHtmlBadFormatException {
		String input = " <table cellpadding=\"value\" cellspacing=\"value\" summary=\"value\">innerHTML - this is a test</table> ";
		String expected = " <table cellpadding=\"value\" cellspacing=\"value\" summary=\"value\">innerHTML - this is a test</table> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementTitleAttribute() throws XHtmlBadFormatException {
		String input = " <table cellpadding=\"value\" cellspacing=\"value\" summary=\"value\" title=\"value\">innerHTML - this is a test</table> ";
		String expected = " <table cellpadding=\"value\" cellspacing=\"value\" summary=\"value\" title=\"value\">innerHTML - this is a test</table> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementNameAttribute() throws XHtmlBadFormatException {
		String input = " <table cellpadding=\"value\" cellspacing=\"value\" summary=\"value\" title=\"value\" name=\"value\">innerHTML - this is a test</table> ";
		String expected = " <table cellpadding=\"value\" cellspacing=\"value\" summary=\"value\" title=\"value\" name=\"value\">innerHTML - this is a test</table> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementBadAttribute() throws XHtmlBadFormatException {
		String input = " <table cellpadding=\"value\" cellspacing=\"value\" summary=\"value\" title=\"value\" name=\"value\" OnClick=\"alert('bad!');\">innerHTML - this is a test</table> ";
		String expected = " <table cellpadding=\"value\" cellspacing=\"value\" summary=\"value\" title=\"value\" name=\"value\">innerHTML - this is a test</table> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

}
