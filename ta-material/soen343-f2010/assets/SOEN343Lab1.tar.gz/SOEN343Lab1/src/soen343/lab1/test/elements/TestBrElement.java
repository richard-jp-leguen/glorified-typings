package soen343.lab1.test.elements;

import junit.framework.TestCase;
import soen343.lab1.XHtmlSanitizer;
import soen343.lab1.exceptions.XHtmlBadFormatException;

public class TestBrElement extends TestCase {

	public void testElementNoAttributes() throws XHtmlBadFormatException {
		String input = " <br />this is a test ";
		String expected = " <br />this is a test ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementBadAttribute() throws XHtmlBadFormatException {
		String input = " <br OnClick=\"alert('bad!');\" />this is a test ";
		String expected = " <br />this is a test ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

}
