package soen343.lab1.test;

import junit.framework.TestCase;
import soen343.lab1.XHtmlSanitizer;
import soen343.lab1.exceptions.XHtmlBadFormatException;

public class TestXHtmlSanitizer extends TestCase {

	public void testSingleElement() throws XHtmlBadFormatException {
		String input = " <span>This is a test</span> ";
		String expected = " <span>This is a test</span> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected, output);
	}
	
	public void testNestedElement() throws XHtmlBadFormatException {
		String input = " <div><span>This is a test</span></div> ";
		String expected = " <div><span>This is a test</span></div> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected, output);
	}
	
	public void testNestedElementWithAttributes() throws XHtmlBadFormatException {
		String input = " <div title=\"outter\"><span name=\"inner\">This is a test</span></div> ";
		String expected = " <div title=\"outter\"><span name=\"inner\">This is a test</span></div> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected, output);
	}
	
	public void testSingleElementWithAttribute() throws XHtmlBadFormatException {
		String input = " <h1 title=\"Test #2\">This is a test</h1> ";
		String expected = " <h1 title=\"Test #2\">This is a test</h1> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected, output);
	}
	
	public void testSingleElementWithMultipleAttributes() throws XHtmlBadFormatException {
		String input = " <h1 title=\"Test #3\" name=\"Test #3\">This is a test</h1> ";
		String expected = " <h1 title=\"Test #3\" name=\"Test #3\">This is a test</h1> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected, output);
	}
	
}
