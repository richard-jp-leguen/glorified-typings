package soen343.lab1.test.elements;

import junit.framework.TestCase;
import soen343.lab1.XHtmlSanitizer;
import soen343.lab1.exceptions.XHtmlBadFormatException;

public class TestH2Element extends TestCase {

	public void testElementNoAttributes() throws XHtmlBadFormatException {
		String input = " <h2>innerHTML - this is a test</h2> ";
		String expected = " <h2>innerHTML - this is a test</h2> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementTitleAttribute() throws XHtmlBadFormatException {
		String input = " <h2 title=\"value\">innerHTML - this is a test</h2> ";
		String expected = " <h2 title=\"value\">innerHTML - this is a test</h2> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementNameAttribute() throws XHtmlBadFormatException {
		String input = " <h2 title=\"value\" name=\"value\">innerHTML - this is a test</h2> ";
		String expected = " <h2 title=\"value\" name=\"value\">innerHTML - this is a test</h2> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementBadAttribute() throws XHtmlBadFormatException {
		String input = " <h2 title=\"value\" name=\"value\" OnClick=\"alert('bad!');\">innerHTML - this is a test</h2> ";
		String expected = " <h2 title=\"value\" name=\"value\">innerHTML - this is a test</h2> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

}
