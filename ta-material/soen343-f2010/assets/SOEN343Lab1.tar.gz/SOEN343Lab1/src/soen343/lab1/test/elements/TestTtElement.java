package soen343.lab1.test.elements;

import junit.framework.TestCase;
import soen343.lab1.XHtmlSanitizer;
import soen343.lab1.exceptions.XHtmlBadFormatException;

public class TestTtElement extends TestCase {

	public void testElementNoAttributes() throws XHtmlBadFormatException {
		String input = " <tt>innerHTML - this is a test</tt> ";
		String expected = " <tt>innerHTML - this is a test</tt> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementTitleAttribute() throws XHtmlBadFormatException {
		String input = " <tt title=\"value\">innerHTML - this is a test</tt> ";
		String expected = " <tt title=\"value\">innerHTML - this is a test</tt> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementNameAttribute() throws XHtmlBadFormatException {
		String input = " <tt title=\"value\" name=\"value\">innerHTML - this is a test</tt> ";
		String expected = " <tt title=\"value\" name=\"value\">innerHTML - this is a test</tt> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementBadAttribute() throws XHtmlBadFormatException {
		String input = " <tt title=\"value\" name=\"value\" OnClick=\"alert('bad!');\">innerHTML - this is a test</tt> ";
		String expected = " <tt title=\"value\" name=\"value\">innerHTML - this is a test</tt> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

}
