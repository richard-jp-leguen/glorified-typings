package soen343.lab1.test.elements;

import junit.framework.TestCase;
import soen343.lab1.XHtmlSanitizer;
import soen343.lab1.exceptions.XHtmlBadFormatException;

public class TestOlElement extends TestCase {

	public void testElementNoAttributes() throws XHtmlBadFormatException {
		String input = " <ol>innerHTML - this is a test</ol> ";
		String expected = " <ol>innerHTML - this is a test</ol> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementBadAttribute() throws XHtmlBadFormatException {
		String input = " <ol OnClick=\"alert('bad!');\">innerHTML - this is a test</ol> ";
		String expected = " <ol>innerHTML - this is a test</ol> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

}
