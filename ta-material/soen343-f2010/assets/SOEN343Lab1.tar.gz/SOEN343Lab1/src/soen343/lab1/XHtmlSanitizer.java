package soen343.lab1;

import java.util.HashMap;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import soen343.lab1.exceptions.XHtmlBadFormatException;
/**
 * 
 * @author A developer who is no longer with the company
 * The purpose of this class is to sanitize XHTML authored by end users, to ensure the web site is not vulnerable to Cross Site Scripting Attacks.
 */
public class XHtmlSanitizer {

	/**
	 * This array serves as a white list of 'safe' XHTML elements and attributes
	 * Only (**only**) those items listed in this array are permitted in XHTML created using the authoring tool.
	 * Adding a new item to this list (respecting the formatting) should allow a new element/attribute.
	 * The formating is a variation of the syntax used for DTDs.
	 * 
	 *  Any attributes <!ATTLIST > apply to the most recent <!ELEMENT >
	 *  So	"<!ELEMENT a>",
			"<!ATTLIST href>",
			"<!ATTLIST coords>",
			"<!ATTLIST title>",
			means that the anchor element has acceptable attributes href, coords and title.
	 */
	private static String[] whiteList = new String[] {
														"<!ELEMENT a>",
														"<!ATTLIST href>",
														"<!ATTLIST coords>",
														"<!ATTLIST title>",
														"<!ELEMENT abbr>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT acronym>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT adress>",
														"<!ELEMENT area>",
														"<!ATTLIST shape>",
														"<!ATTLIST coords>",
														"<!ATTLIST href>",
														"<!ATTLIST nohref>",
														"<!ELEMENT blockquote>",
														"<!ATTLIST cite>",
														"<!ELEMENT br>",
														"<!ELEMENT caption>",
														"<!ELEMENT cite>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT code>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT del>",
														"<!ATTLIST cite>",
														"<!ATTLIST datetime>",
														"<!ELEMENT dd>",
														"<!ELEMENT dfn>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT div>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT dl>",
														"<!ELEMENT dt>",
														"<!ELEMENT em>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT h1>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT h2>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT h3>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT h4>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT h5>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT h6>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT hr>",
														"<!ELEMENT img>",
														"<!ATTLIST src>",
														"<!ATTLIST width>",
														"<!ATTLIST height>",
														"<!ATTLIST alt>",
														"<!ATTLIST usemap>",
														"<!ATTLIST title>",
														"<!ELEMENT ins>",
														"<!ATTLIST cite>",
														"<!ATTLIST datetime>",
														"<!ATTLIST title>",
														"<!ELEMENT kbd>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT li>",
														"<!ELEMENT map>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT ol>",
														"<!ELEMENT p>",
														"<!ELEMENT pre>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT q>",
														"<!ATTLIST cite>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT samp>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT span>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT strong>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT sup>",
														"<!ELEMENT sub>",
														"<!ELEMENT table>",
														"<!ATTLIST cellpadding>",
														"<!ATTLIST cellspacing>",
														"<!ATTLIST summary>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT tbody>",
														"<!ELEMENT td>",
														"<!ATTLIST headers>",
														"<!ATTLIST colspan>",
														"<!ATTLIST rowspan>",
														"<!ATTLIST axis>",
														"<!ELEMENT tfoot>",
														"<!ELEMENT thead>",
														"<!ELEMENT th>",
														"<!ATTLIST name>",
														"<!ATTLIST scope>",
														"<!ATTLIST colspan>",
														"<!ATTLIST rowspan>",
														"<!ATTLIST axis>",
														"<!ELEMENT tr>",
														"<!ELEMENT tt>",
														"<!ATTLIST title>",
														"<!ATTLIST name>",
														"<!ELEMENT ul>",
														"<!ELEMENT var>",
														"<!ATTLIST title>",
														"<!ATTLIST name>"
														};
	
	/**
	 * @param input	This parameter is the markup which is to be parsed and sanitized.
	 * @return	Sanitized, well-formed XHTML
	 * @throws XHtmlBadFormatException	If input it not well-formed XML
	 */
	public static String sanitize(String input) throws XHtmlBadFormatException {
		StringBuilder output = new StringBuilder();
		StringBuilder _input = new StringBuilder(input);
		parseNodeList(_input, output);
		if(_input!=null && _input.length()>0) {
			throw new XHtmlBadFormatException("Error occured while parsing XHtml; bad formatting. Remainder was: "+input);
		}
		return output.toString();
	}
	
	/**
	 * @param input	a string representation of the input markup to be parsed and sanitized, which presumably begins with a node list. A StringBuilder is used as it is consumed as it is parsed.
	 * @param output	a string builder, to which we append output as we consume input.
	 * @throws XHtmlBadFormatException	If input it not well-formed XML
	 */
	protected static void parseNodeList(StringBuilder input, StringBuilder output) throws XHtmlBadFormatException {
		parseTextNode(input, output);
		while(input.length()>0) {
			parseTextNode(input, output);
			parseElementNode(input, output);
			if(input.length()>1 && input.substring(0,2).equals("</")) {
				return;
			}
		}
	}

	private static Pattern openTagPattern = null;
	private static Pattern attributePattern = null;
	/**
	 * @param input	a string representation of the input markup to be parsed and sanitized, which presumably begins with a element node. A StringBuilder is used as it is consumed as it is parsed.
	 * @param output	a string builder, to which we append output as we consume input.
	 * @throws XHtmlBadFormatException	If input it not well-formed XML
	 */
	protected static void parseElementNode(StringBuilder input, StringBuilder output) throws XHtmlBadFormatException {
		if(openTagPattern==null) {
			openTagPattern = Pattern.compile("^\\<(\\w+)");
		}
		Matcher openTagMatcher = openTagPattern.matcher(input);
		if(openTagMatcher.find()) {
			String tagName = openTagMatcher.group(1);
			XHtmlTag tag = new XHtmlTag(tagName);
			if(!_whiteList.containsKey(tag)) {	// check if the tag is white-listed
				output = new StringBuilder();	// If it is not, then we will use a different StringBuilder to buffer it and its inner HTML.
												// this StringBuilder will be discarded afterwards.
			}
			output.append(openTagMatcher.group());
			input = input.delete(0, openTagMatcher.group().length());
			if(attributePattern==null) {
				attributePattern = Pattern.compile("^\\s+(\\w+)\\=\"([^\\<\\>\"]*)\"");
			}
			Matcher attributeMatcher = null;
			boolean find = false;
			do {
				attributeMatcher = attributePattern.matcher(input);
				find = attributeMatcher.find();
				if(find) {
					String attributeName = attributeMatcher.group(1);
					String attributeValue = attributeMatcher.group(2);
					XHtmlAttribute attribute = new XHtmlAttribute(attributeName);
					
					if(_whiteList.containsKey(tag) && _whiteList.get(tag).contains(attribute)) { // check if the attribute is white-listed for this tag
						output.append(attributeMatcher.group());						
					}
					input.delete(0, attributeMatcher.group().length());
				}
			} while(find);
			parseWhiteSpace(input, output);
			if(input.substring(0,1).equals(">")) {
				input.delete(0,1);
				output.append(">");
				parseNodeList(input, output);
				String closeTag = "</"+tagName+">";
				if(input.length()>=closeTag.length() && input.substring(0, closeTag.length()).equals(closeTag)) {
					input.delete(0,closeTag.length());
					output.append(closeTag);
				}
				else {
					throw new XHtmlBadFormatException("Close tag expected.");
				}
			}
			else if(input.substring(0,2).equals("/>")) {
				output.append(input.substring(0,2));
				input.delete(0,2);
			}
			else {
				throw new XHtmlBadFormatException("Poorly formatted open tag.");
			}
		}
	}

	private static Pattern textNodePattern = null;
	/**
	 * @param input	a string representation of the input markup to be parsed and sanitized, which presumably begins with a text node. A StringBuilder is used as it is consumed as it is parsed.
	 * @param output	a string builder, to which we append output as we consume input.
	 */
	protected static void parseTextNode(StringBuilder input, StringBuilder output) {
		if(textNodePattern==null) {
			textNodePattern = Pattern.compile("^[^\\<\\>]+");
		}
		Matcher textNodeMatcher = textNodePattern.matcher(input);
		if(textNodeMatcher.find()) {
			output.append(textNodeMatcher.group());
			input.delete(0, textNodeMatcher.group().length());
		}
	}
	
	private static Pattern whiteSpacePattern = null;
	/**
	 * @param input	a string representation of the input markup to be parsed and sanitized, which presumably begins with white space. A StringBuilder is used as it is consumed as it is parsed.
	 * @param output	a string builder, to which we append output as we consume input.
	 */
	public static void parseWhiteSpace(StringBuilder input, StringBuilder output) {
		if(whiteSpacePattern==null) {
			whiteSpacePattern = Pattern.compile("^\\s+");
		}
		Matcher whiteSpaceMatcher = whiteSpacePattern.matcher(input);
		if(whiteSpaceMatcher.find()) {
			output.append(whiteSpaceMatcher.group());
			input.delete(0, whiteSpaceMatcher.group().length());
		}
	}
	
	private static HashMap<XHtmlTag, HashSet<XHtmlAttribute>> _whiteList;
	static {
		byte i = 0;
		Pattern elementPattern = Pattern.compile("\\<!ELEMENT (\\w+)\\>");
		Pattern attributePattern = Pattern.compile("\\<!ATTLIST (\\w+)\\>");
		_whiteList = new HashMap<XHtmlTag, HashSet<XHtmlAttribute>>();
		while(i>=0 && i<whiteList.length) {
			Matcher elementMatcher = elementPattern.matcher(whiteList[i]);
			if(elementMatcher.find()) {
				String tagName = elementMatcher.group(1);
				XHtmlTag tag = new XHtmlTag(tagName);
				if(!_whiteList.containsKey(tag)) {
					_whiteList.put(tag, new HashSet<XHtmlAttribute>());
				}
				boolean find = false;
				do {
					Matcher attributeMatcher = attributePattern.matcher(whiteList[i+1]);
					find = attributeMatcher.find();
					if(find) {
						String attName = attributeMatcher.group(1);
						XHtmlAttribute attribute = new XHtmlAttribute(attName);
						if(!_whiteList.get(tag).contains(attribute)) {
							_whiteList.get(tag).add(attribute);
						}
						i++;
					}
				}while(find && i+1>0 && i+1<whiteList.length);
			}
			i++;
		}
	}
	
}
