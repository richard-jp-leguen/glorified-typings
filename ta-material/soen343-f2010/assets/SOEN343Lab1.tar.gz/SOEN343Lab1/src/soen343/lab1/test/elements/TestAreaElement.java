package soen343.lab1.test.elements;

import junit.framework.TestCase;
import soen343.lab1.XHtmlSanitizer;
import soen343.lab1.exceptions.XHtmlBadFormatException;

public class TestAreaElement extends TestCase {

	public void testElementNoAttributes() throws XHtmlBadFormatException {
		String input = " <area>innerHTML - this is a test</area> ";
		String expected = " <area>innerHTML - this is a test</area> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementShapeAttribute() throws XHtmlBadFormatException {
		String input = " <area shape=\"value\">innerHTML - this is a test</area> ";
		String expected = " <area shape=\"value\">innerHTML - this is a test</area> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementCoordsAttribute() throws XHtmlBadFormatException {
		String input = " <area shape=\"value\" coords=\"value\">innerHTML - this is a test</area> ";
		String expected = " <area shape=\"value\" coords=\"value\">innerHTML - this is a test</area> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementHrefAttribute() throws XHtmlBadFormatException {
		String input = " <area shape=\"value\" coords=\"value\" href=\"value\">innerHTML - this is a test</area> ";
		String expected = " <area shape=\"value\" coords=\"value\" href=\"value\">innerHTML - this is a test</area> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementNohrefAttribute() throws XHtmlBadFormatException {
		String input = " <area shape=\"value\" coords=\"value\" href=\"value\" nohref=\"value\">innerHTML - this is a test</area> ";
		String expected = " <area shape=\"value\" coords=\"value\" href=\"value\" nohref=\"value\">innerHTML - this is a test</area> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementBadAttribute() throws XHtmlBadFormatException {
		String input = " <area shape=\"value\" coords=\"value\" href=\"value\" nohref=\"value\" OnClick=\"alert('bad!');\">innerHTML - this is a test</area> ";
		String expected = " <area shape=\"value\" coords=\"value\" href=\"value\" nohref=\"value\">innerHTML - this is a test</area> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

}
