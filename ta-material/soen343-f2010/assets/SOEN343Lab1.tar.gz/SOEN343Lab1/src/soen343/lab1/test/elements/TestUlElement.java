package soen343.lab1.test.elements;

import junit.framework.TestCase;
import soen343.lab1.XHtmlSanitizer;
import soen343.lab1.exceptions.XHtmlBadFormatException;

public class TestUlElement extends TestCase {

	public void testElementNoAttributes() throws XHtmlBadFormatException {
		String input = " <ul>innerHTML - this is a test</ul> ";
		String expected = " <ul>innerHTML - this is a test</ul> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementBadAttribute() throws XHtmlBadFormatException {
		String input = " <ul OnClick=\"alert('bad!');\">innerHTML - this is a test</ul> ";
		String expected = " <ul>innerHTML - this is a test</ul> ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

}
