package soen343.lab1.test;

import junit.framework.TestCase;
import soen343.lab1.XHtmlSanitizer;
import soen343.lab1.exceptions.XHtmlBadFormatException;

public class TestXHtmlBadFormatting extends TestCase {

	public void testUnclosedElement() throws XHtmlBadFormatException {
		try {
			String input = " <span>This is a test ";
			XHtmlSanitizer.sanitize(input);
			fail("XHtmlBadFormatException exception expected");
		}
		catch(XHtmlBadFormatException e) {
			assertTrue(true);
		}
	}
	
	public void testNestedElement() throws XHtmlBadFormatException {
		try {
			String input = " <div><span>This is a test</div> ";
			XHtmlSanitizer.sanitize(input);
			fail("XHtmlBadFormatException exception expected");
		}
		catch(XHtmlBadFormatException e) {
			assertTrue(true);
		}
	}
	
	public void testNestedElementWithAttributes() throws XHtmlBadFormatException {
		try {
			String input = " <div title=\"outter\"><span name=\"inner\">This is a test</span> ";
			XHtmlSanitizer.sanitize(input);
			fail("XHtmlBadFormatException exception expected");
		}
		catch(XHtmlBadFormatException e) {
			assertTrue(true);
		}
	}
	
	public void testSingleElementWithAttribute() throws XHtmlBadFormatException {
		try {
			String input = " <h1 title=\"Test #2\">This is a test";
			XHtmlSanitizer.sanitize(input);
			fail("XHtmlBadFormatException exception expected");
		}
		catch(XHtmlBadFormatException e) {
			assertTrue(true);
		}
	}
	
	public void testSingleElementWithMultipleAttributes() throws XHtmlBadFormatException {
		try {
			String input = " <h1 title=\"Test #3\" name=\"Test #3\">This is a test ";
			XHtmlSanitizer.sanitize(input);
			fail("XHtmlBadFormatException exception expected");
		}
		catch(XHtmlBadFormatException e) {
			assertTrue(true);
		}
	}
	
	public void testExtraCloseTag() throws XHtmlBadFormatException {
		try {
			String input = " This is a test</var> ";
			XHtmlSanitizer.sanitize(input);
			fail("XHtmlBadFormatException exception expected");
		}
		catch(XHtmlBadFormatException e) {
			assertTrue(true);
		}
	}
	
}
