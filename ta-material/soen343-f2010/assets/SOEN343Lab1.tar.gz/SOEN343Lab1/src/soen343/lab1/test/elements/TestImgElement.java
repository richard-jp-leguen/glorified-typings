package soen343.lab1.test.elements;

import junit.framework.TestCase;
import soen343.lab1.XHtmlSanitizer;
import soen343.lab1.exceptions.XHtmlBadFormatException;

public class TestImgElement extends TestCase {

	public void testElementNoAttributes() throws XHtmlBadFormatException {
		String input = " <img />this is a test ";
		String expected = " <img />this is a test ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementSrcAttribute() throws XHtmlBadFormatException {
		String input = " <img src=\"value\" />this is a test ";
		String expected = " <img src=\"value\" />this is a test ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementWidthAttribute() throws XHtmlBadFormatException {
		String input = " <img src=\"value\" width=\"value\" />this is a test ";
		String expected = " <img src=\"value\" width=\"value\" />this is a test ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementHeightAttribute() throws XHtmlBadFormatException {
		String input = " <img src=\"value\" width=\"value\" height=\"value\" />this is a test ";
		String expected = " <img src=\"value\" width=\"value\" height=\"value\" />this is a test ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementAltAttribute() throws XHtmlBadFormatException {
		String input = " <img src=\"value\" width=\"value\" height=\"value\" alt=\"value\" />this is a test ";
		String expected = " <img src=\"value\" width=\"value\" height=\"value\" alt=\"value\" />this is a test ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementUsemapAttribute() throws XHtmlBadFormatException {
		String input = " <img src=\"value\" width=\"value\" height=\"value\" alt=\"value\" usemap=\"value\" />this is a test ";
		String expected = " <img src=\"value\" width=\"value\" height=\"value\" alt=\"value\" usemap=\"value\" />this is a test ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementTitleAttribute() throws XHtmlBadFormatException {
		String input = " <img src=\"value\" width=\"value\" height=\"value\" alt=\"value\" usemap=\"value\" title=\"value\" />this is a test ";
		String expected = " <img src=\"value\" width=\"value\" height=\"value\" alt=\"value\" usemap=\"value\" title=\"value\" />this is a test ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

	public void testElementBadAttribute() throws XHtmlBadFormatException {
		String input = " <img src=\"value\" width=\"value\" height=\"value\" alt=\"value\" usemap=\"value\" title=\"value\" OnClick=\"alert('bad!');\" />this is a test ";
		String expected = " <img src=\"value\" width=\"value\" height=\"value\" alt=\"value\" usemap=\"value\" title=\"value\" />this is a test ";
		String output = XHtmlSanitizer.sanitize(input);
		assertEquals("Expected output did not match actual output.", expected,
				output);
	}

}
